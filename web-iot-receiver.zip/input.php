<?php
// input.php - PHP Bridge untuk ESP32 ke Neon DB
// Endpoint untuk menerima data dari ESP32 (HTTP POST)

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

// 1. Ambil Data dari ESP32 (menggunakan POST form-data)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "Method Not Allowed. Use POST.";
    exit;
}

// Ambil parameter dari POST
$ph = isset($_POST['ph']) ? floatval($_POST['ph']) : null;
$battery = isset($_POST['battery']) ? floatval($_POST['battery']) : null;
$location = isset($_POST['location']) ? $_POST['location'] : null;

// Validasi input
if ($ph === null || $battery === null || $location === null) {
    http_response_code(400);
    echo "Gagal: Data tidak lengkap. Kirim ph, battery, dan location.";
    exit;
}

// 2. Koneksi ke MySQL Database - Load dari .env
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
        }
    }
}

$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$dbname = $_ENV['DB_NAME'] ?? 'iot_database';

// Koneksi dengan mysqli (Style Procedural - cocok untuk hosting umum)
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    http_response_code(500);
    echo "Koneksi DB Gagal: " . mysqli_connect_error();
    error_log("Database connection failed: " . mysqli_connect_error());
    exit;
}

// 3. Masukkan Data ke Database
// Pastikan tabel monitoring_logs sudah ada!

try {
    // Prepare Statement untuk keamanan
    $query = "INSERT INTO monitoring_logs (ph_value, battery_level, location, created_at) VALUES (?, ?, ?, NOW())";
    
    $stmt = mysqli_prepare($conn, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "dds", $ph, $battery, $location); // d=double, s=string
        $result = mysqli_stmt_execute($stmt);
        
        if ($result) {
            http_response_code(200);
            echo "Sukses Masuk MySQL! Data: pH=$ph, Battery=$battery%, Location=$location";
        } else {
            http_response_code(500);
            echo "Gagal Input: " . mysqli_stmt_error($stmt);
            error_log("Insert failed: " . mysqli_stmt_error($stmt));
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal Prepare Statement: " . mysqli_error($conn);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo "Error: " . $e->getMessage();
}

// Tutup koneksi
mysqli_close($conn);
?>
