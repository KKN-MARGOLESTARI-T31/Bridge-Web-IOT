<?php
echo "Extension Dir: " . ini_get('extension_dir') . "\n";
echo "Scan Dir: " . ini_get('scan_dir') . "\n";
?>
